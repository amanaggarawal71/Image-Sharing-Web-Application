import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.sql.DataSource;
@MultipartConfig(maxFileSize=10000000)
@WebServlet(name = "UploadServlet", urlPatterns = {"/upload"})
public class UploadServlet extends HttpServlet {
    
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
         
       PrintWriter pw=null;
        try{
            pw =resp.getWriter();
            String filename=req.getParameter("fname");
            String category=req.getParameter("theme");
            int page=1;
            try{
            page=Integer.parseInt(req.getParameter("page"));}
            catch(Exception e)
            {}
            //System.out.println(category);
            Part p=req.getPart("file");
           InputStream in=p.getInputStream();
           //pw.println(p);
           InitialContext ctx=new InitialContext();
           DataSource ds=(DataSource)ctx.lookup("jdbc/my");
           Connection con=ds.getConnection();
        PreparedStatement pst=con.prepareStatement("insert into imagefile values(?,?,?)");
        pst.setString(1,filename);
        pst.setBlob(2,in);
        pst.setString(3,category);
        pst.executeUpdate();
        pst.close();
        con.close();
        in.close();
       resp.sendRedirect("Home.jsp?page="+page);
        }
        catch(Exception e)
        {pw.println(e);}
    }
}
