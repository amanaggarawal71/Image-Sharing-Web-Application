import com.google.common.io.ByteStreams;
import java.io.*;
import java.sql.*;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
@WebServlet(name = "DownloadServlet1", urlPatterns = {"/download1"})
public class DownloadServlet1 extends HttpServlet {

      @Override
        protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try{
        int num=Integer.parseInt(req.getParameter("image"));
        String srch=req.getParameter("srch");
        InitialContext ctx=new InitialContext();
        DataSource ds=(DataSource)ctx.lookup("jdbc/my");
        Connection con=ds.getConnection();
        PreparedStatement pst=con.prepareStatement("select * from imagefile where lower(filename) like ? or lower(category) like ?");
        pst.setString(1,"%"+srch+"%");
        pst.setString(2,"%"+srch+"%");
        ResultSet rs=pst.executeQuery();
        int i=1;
        while(rs.next()&&i<num){
            i++;
        }
        String filename=rs.getString(1);
        int index=filename.lastIndexOf("jpg");
        if(index==-1)
        {
            filename=filename+".jpg";
        }
        InputStream in=rs.getBinaryStream(2);
        rs.close();
        pst.close();
        con.close();
        byte b[]=new byte[1024*1024*4];
        ServletOutputStream out=resp.getOutputStream();
        resp.setContentType("multipart/form-data");
        resp.setHeader("Content-Disposition","attachment;filename="+filename);
        int read=-1;
        while((read=in.read(b))!=-1)
        {out.write(b,0,read);}
        in.close();
        out.close();
   }
        catch(Exception e)
        {}
    }
    
}
